module.exports = {
  source: './data/templates/template.less',
  target: './less/pesticide.less',
  entry: '\t%s { outline: 1px solid %s !important; }'
};
