module.exports = {
  source: './data/templates/template.js',
  target: './js/pesticide.js',
  entry: '\t\t\t\'%s\': \'%s\','
};
