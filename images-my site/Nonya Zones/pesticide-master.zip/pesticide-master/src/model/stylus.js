module.exports = {
  source: './data/templates/template.styl',
  target: './stylus/pesticide.styl',
  entry: '  %s\n\t\toutline 1px solid %s !important'
};
