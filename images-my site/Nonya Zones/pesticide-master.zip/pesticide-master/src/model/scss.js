module.exports = {
  source: './data/templates/template.scss',
  target: './sass/pesticide.scss',
  entry: '  %s { outline: 1px solid %s !important; }'
};
